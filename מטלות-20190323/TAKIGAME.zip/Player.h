#ifndef PLAYER_H
#define PLAYER_H
#include "Card.h"
class Player {
private:
	// name;
	// num_of_cards;
	// container of cards
	// more private members

public:

};
#endif



